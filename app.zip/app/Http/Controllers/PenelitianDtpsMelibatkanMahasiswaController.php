<?php

namespace App\Http\Controllers;

use App\Models\PenelitianDtpsMelibatkanMahasiswa;
use Illuminate\Http\Request;

class PenelitianDtpsMelibatkanMahasiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PenelitianDtpsMelibatkanMahasiswa  $penelitianDtpsMelibatkanMahasiswa
     * @return \Illuminate\Http\Response
     */
    public function show(PenelitianDtpsMelibatkanMahasiswa $penelitianDtpsMelibatkanMahasiswa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PenelitianDtpsMelibatkanMahasiswa  $penelitianDtpsMelibatkanMahasiswa
     * @return \Illuminate\Http\Response
     */
    public function edit(PenelitianDtpsMelibatkanMahasiswa $penelitianDtpsMelibatkanMahasiswa)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PenelitianDtpsMelibatkanMahasiswa  $penelitianDtpsMelibatkanMahasiswa
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PenelitianDtpsMelibatkanMahasiswa $penelitianDtpsMelibatkanMahasiswa)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PenelitianDtpsMelibatkanMahasiswa  $penelitianDtpsMelibatkanMahasiswa
     * @return \Illuminate\Http\Response
     */
    public function destroy(PenelitianDtpsMelibatkanMahasiswa $penelitianDtpsMelibatkanMahasiswa)
    {
        //
    }
}
