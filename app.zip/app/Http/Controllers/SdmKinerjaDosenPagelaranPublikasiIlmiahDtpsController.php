<?php

namespace App\Http\Controllers;

use App\Models\SdmKinerjaDosenPagelaranPublikasiIlmiahDtps;
use Illuminate\Http\Request;

class SdmKinerjaDosenPagelaranPublikasiIlmiahDtpsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SdmKinerjaDosenPagelaranPublikasiIlmiahDtps  $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps
     * @return \Illuminate\Http\Response
     */
    public function show(SdmKinerjaDosenPagelaranPublikasiIlmiahDtps $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SdmKinerjaDosenPagelaranPublikasiIlmiahDtps  $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps
     * @return \Illuminate\Http\Response
     */
    public function edit(SdmKinerjaDosenPagelaranPublikasiIlmiahDtps $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SdmKinerjaDosenPagelaranPublikasiIlmiahDtps  $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SdmKinerjaDosenPagelaranPublikasiIlmiahDtps $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SdmKinerjaDosenPagelaranPublikasiIlmiahDtps  $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps
     * @return \Illuminate\Http\Response
     */
    public function destroy(SdmKinerjaDosenPagelaranPublikasiIlmiahDtps $sdmKinerjaDosenPagelaranPublikasiIlmiahDtps)
    {
        //
    }
}
