<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SdmKinerjaDosenPengakuanDtps extends Model
{
    use HasFactory;
    protected $table = 'sdm_kinerja_dosen_pengakuan_dtps';
    protected $guarded = ['id'];
}
