-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 24 Mar 2022 pada 12.57
-- Versi server: 5.7.33
-- Versi PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tes`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `simulasi_penilaians`
--

CREATE TABLE `simulasi_penilaians` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `point_1` double(8,2) DEFAULT NULL,
  `point_1_akhir` double(8,2) DEFAULT NULL,
  `point_2` double(8,2) DEFAULT NULL,
  `point_2_akhir` double(8,2) DEFAULT NULL,
  `point_3` double(8,2) DEFAULT NULL,
  `point_3_akhir` double(8,2) DEFAULT NULL,
  `point_4` double(8,2) DEFAULT NULL,
  `point_4_akhir` double(8,2) DEFAULT NULL,
  `point_5` double(8,2) DEFAULT NULL,
  `point_5_akhir` double(8,2) DEFAULT NULL,
  `point_6a` double(8,2) DEFAULT NULL,
  `point_6b` double(8,2) DEFAULT NULL,
  `point_6_akhir` double(8,2) DEFAULT NULL,
  `point_7a` double(8,2) DEFAULT NULL,
  `point_7b` double(8,2) DEFAULT NULL,
  `point_7_akhir` double(8,2) DEFAULT NULL,
  `point_8` double(8,2) DEFAULT NULL,
  `point_8_akhir` double(8,2) DEFAULT NULL,
  `point_9a` double(8,2) DEFAULT NULL,
  `point_9b` double(8,2) DEFAULT NULL,
  `point_9_akhir` double(8,2) DEFAULT NULL,
  `point_10` double(8,2) DEFAULT NULL,
  `point_10_akhir` double(8,2) DEFAULT NULL,
  `point_11` double(8,2) DEFAULT NULL,
  `point_11_akhir` double(8,2) DEFAULT NULL,
  `point_12` double(8,2) DEFAULT NULL,
  `point_12_akhir` double(8,2) DEFAULT NULL,
  `point_13` double(8,2) DEFAULT NULL,
  `point_13_akhir` double(8,2) DEFAULT NULL,
  `point_14` double(8,2) DEFAULT NULL,
  `point_14_akhir` double(8,2) DEFAULT NULL,
  `point_15a` double(8,2) DEFAULT NULL,
  `point_15b` double(8,2) DEFAULT NULL,
  `point_15_akhir` double(8,2) DEFAULT NULL,
  `point_16a` double(8,2) DEFAULT NULL,
  `point_16b` double(8,2) DEFAULT NULL,
  `point_16_akhir` double(8,2) DEFAULT NULL,
  `point_17` double(8,2) DEFAULT NULL,
  `point_17_akhir` double(8,2) DEFAULT NULL,
  `point_18` double(8,2) DEFAULT NULL,
  `point_18_akhir` double(8,2) DEFAULT NULL,
  `point_19` double(8,2) DEFAULT NULL,
  `point_19_akhir` double(8,2) DEFAULT NULL,
  `point_20` double(8,2) DEFAULT NULL,
  `point_20_akhir` double(8,2) DEFAULT NULL,
  `point_21` double(8,2) DEFAULT NULL,
  `point_21_akhir` double(8,2) DEFAULT NULL,
  `point_22` double(8,2) DEFAULT NULL,
  `point_22_akhir` double(8,2) DEFAULT NULL,
  `point_23` double(8,2) DEFAULT NULL,
  `point_23_akhir` double(8,2) DEFAULT NULL,
  `point_24` double(8,2) DEFAULT NULL,
  `point_24_akhir` double(8,2) DEFAULT NULL,
  `point_25` double(8,2) DEFAULT NULL,
  `point_25_akhir` double(8,2) DEFAULT NULL,
  `point_26` double(8,2) DEFAULT NULL,
  `point_26_akhir` double(8,2) DEFAULT NULL,
  `point_27` double(8,2) DEFAULT NULL,
  `point_27_akhir` double(8,2) DEFAULT NULL,
  `point_28` double(8,2) DEFAULT NULL,
  `point_28_akhir` double(8,2) DEFAULT NULL,
  `point_29` double(8,2) DEFAULT NULL,
  `point_29_akhir` double(8,2) DEFAULT NULL,
  `point_30` double(8,2) DEFAULT NULL,
  `point_30_akhir` double(8,2) DEFAULT NULL,
  `point_31a` double(8,2) DEFAULT NULL,
  `point_31b` double(8,2) DEFAULT NULL,
  `point_31_akhir` double(8,2) DEFAULT NULL,
  `point_32` double(8,2) DEFAULT NULL,
  `point_32_akhir` double(8,2) DEFAULT NULL,
  `point_33` double(8,2) DEFAULT NULL,
  `point_33_akhir` double(8,2) DEFAULT NULL,
  `point_34` double(8,2) DEFAULT NULL,
  `point_34_akhir` double(8,2) DEFAULT NULL,
  `point_35` double(8,2) DEFAULT NULL,
  `point_35_akhir` double(8,2) DEFAULT NULL,
  `point_36` double(8,2) DEFAULT NULL,
  `point_36_akhir` double(8,2) DEFAULT NULL,
  `point_37` double(8,2) DEFAULT NULL,
  `point_37_akhir` double(8,2) DEFAULT NULL,
  `point_38a` double(8,2) DEFAULT NULL,
  `point_38b` double(8,2) DEFAULT NULL,
  `point_38c` double(8,2) DEFAULT NULL,
  `point_38_akhir` double(8,2) DEFAULT NULL,
  `point_39` double(8,2) DEFAULT NULL,
  `point_39_akhir` double(8,2) DEFAULT NULL,
  `point_40a` double(8,2) DEFAULT NULL,
  `point_40b` double(8,2) DEFAULT NULL,
  `point_40_akhir` double(8,2) DEFAULT NULL,
  `point_41a` double(8,2) DEFAULT NULL,
  `point_41b` double(8,2) DEFAULT NULL,
  `point_41c` double(8,2) DEFAULT NULL,
  `point_41d` double(8,2) DEFAULT NULL,
  `point_41e` double(8,2) DEFAULT NULL,
  `point_41_akhir` double(8,2) DEFAULT NULL,
  `point_42` double(8,2) DEFAULT NULL,
  `point_42_akhir` double(8,2) DEFAULT NULL,
  `point_43` double(8,2) DEFAULT NULL,
  `point_43_akhir` double(8,2) DEFAULT NULL,
  `point_44a` double(8,2) DEFAULT NULL,
  `point_44b` double(8,2) DEFAULT NULL,
  `point_44c` double(8,2) DEFAULT NULL,
  `point_44_akhir` double(8,2) DEFAULT NULL,
  `point_45` double(8,2) DEFAULT NULL,
  `point_45_akhir` double(8,2) DEFAULT NULL,
  `point_46` double(8,2) DEFAULT NULL,
  `point_46_akhir` double(8,2) DEFAULT NULL,
  `point_47a` double(8,2) DEFAULT NULL,
  `point_47b` double(8,2) DEFAULT NULL,
  `point_47_akhir` double(8,2) DEFAULT NULL,
  `point_48` double(8,2) DEFAULT NULL,
  `point_48_akhir` double(8,2) DEFAULT NULL,
  `point_49` double(8,2) DEFAULT NULL,
  `point_49_akhir` double(8,2) DEFAULT NULL,
  `point_50` double(8,2) DEFAULT NULL,
  `point_50_akhir` double(8,2) DEFAULT NULL,
  `point_51` double(8,2) DEFAULT NULL,
  `point_51_akhir` double(8,2) DEFAULT NULL,
  `point_52` double(8,2) DEFAULT NULL,
  `point_52_akhir` double(8,2) DEFAULT NULL,
  `point_53` double(8,2) DEFAULT NULL,
  `point_53_akhir` double(8,2) DEFAULT NULL,
  `point_54` double(8,2) DEFAULT NULL,
  `point_54_akhir` double(8,2) DEFAULT NULL,
  `point_55` double(8,2) DEFAULT NULL,
  `point_55_akhir` double(8,2) DEFAULT NULL,
  `point_56` double(8,2) DEFAULT NULL,
  `point_56_akhir` double(8,2) DEFAULT NULL,
  `point_57` double(8,2) DEFAULT NULL,
  `point_57_akhir` double(8,2) DEFAULT NULL,
  `point_58` double(8,2) DEFAULT NULL,
  `point_58_akhir` double(8,2) DEFAULT NULL,
  `point_59` double(8,2) DEFAULT NULL,
  `point_59_akhir` double(8,2) DEFAULT NULL,
  `point_60` double(8,2) DEFAULT NULL,
  `point_60_akhir` double(8,2) DEFAULT NULL,
  `point_61` double(8,2) DEFAULT NULL,
  `point_61_akhir` double(8,2) DEFAULT NULL,
  `point_62` double(8,2) DEFAULT NULL,
  `point_62_akhir` double(8,2) DEFAULT NULL,
  `point_63` double(8,2) DEFAULT NULL,
  `point_63_akhir` double(8,2) DEFAULT NULL,
  `point_64` double(8,2) DEFAULT NULL,
  `point_64_akhir` double(8,2) DEFAULT NULL,
  `point_65` double(8,2) DEFAULT NULL,
  `point_65_akhir` double(8,2) DEFAULT NULL,
  `point_66` double(8,2) DEFAULT NULL,
  `point_66_akhir` double(8,2) DEFAULT NULL,
  `point_67` double(8,2) DEFAULT NULL,
  `point_67_akhir` double(8,2) DEFAULT NULL,
  `point_68` double(8,2) DEFAULT NULL,
  `point_68_akhir` double(8,2) DEFAULT NULL,
  `point_69` double(8,2) DEFAULT NULL,
  `point_69_akhir` double(8,2) DEFAULT NULL,
  `tahun_laporan` int(11) NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `prodi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `simulasi_penilaians`
--

INSERT INTO `simulasi_penilaians` (`id`, `point_1`, `point_1_akhir`, `point_2`, `point_2_akhir`, `point_3`, `point_3_akhir`, `point_4`, `point_4_akhir`, `point_5`, `point_5_akhir`, `point_6a`, `point_6b`, `point_6_akhir`, `point_7a`, `point_7b`, `point_7_akhir`, `point_8`, `point_8_akhir`, `point_9a`, `point_9b`, `point_9_akhir`, `point_10`, `point_10_akhir`, `point_11`, `point_11_akhir`, `point_12`, `point_12_akhir`, `point_13`, `point_13_akhir`, `point_14`, `point_14_akhir`, `point_15a`, `point_15b`, `point_15_akhir`, `point_16a`, `point_16b`, `point_16_akhir`, `point_17`, `point_17_akhir`, `point_18`, `point_18_akhir`, `point_19`, `point_19_akhir`, `point_20`, `point_20_akhir`, `point_21`, `point_21_akhir`, `point_22`, `point_22_akhir`, `point_23`, `point_23_akhir`, `point_24`, `point_24_akhir`, `point_25`, `point_25_akhir`, `point_26`, `point_26_akhir`, `point_27`, `point_27_akhir`, `point_28`, `point_28_akhir`, `point_29`, `point_29_akhir`, `point_30`, `point_30_akhir`, `point_31a`, `point_31b`, `point_31_akhir`, `point_32`, `point_32_akhir`, `point_33`, `point_33_akhir`, `point_34`, `point_34_akhir`, `point_35`, `point_35_akhir`, `point_36`, `point_36_akhir`, `point_37`, `point_37_akhir`, `point_38a`, `point_38b`, `point_38c`, `point_38_akhir`, `point_39`, `point_39_akhir`, `point_40a`, `point_40b`, `point_40_akhir`, `point_41a`, `point_41b`, `point_41c`, `point_41d`, `point_41e`, `point_41_akhir`, `point_42`, `point_42_akhir`, `point_43`, `point_43_akhir`, `point_44a`, `point_44b`, `point_44c`, `point_44_akhir`, `point_45`, `point_45_akhir`, `point_46`, `point_46_akhir`, `point_47a`, `point_47b`, `point_47_akhir`, `point_48`, `point_48_akhir`, `point_49`, `point_49_akhir`, `point_50`, `point_50_akhir`, `point_51`, `point_51_akhir`, `point_52`, `point_52_akhir`, `point_53`, `point_53_akhir`, `point_54`, `point_54_akhir`, `point_55`, `point_55_akhir`, `point_56`, `point_56_akhir`, `point_57`, `point_57_akhir`, `point_58`, `point_58_akhir`, `point_59`, `point_59_akhir`, `point_60`, `point_60_akhir`, `point_61`, `point_61_akhir`, `point_62`, `point_62_akhir`, `point_63`, `point_63_akhir`, `point_64`, `point_64_akhir`, `point_65`, `point_65_akhir`, `point_66`, `point_66_akhir`, `point_67`, `point_67_akhir`, `point_68`, `point_68_akhir`, `point_69`, `point_69_akhir`, `tahun_laporan`, `is_approved`, `prodi`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2020, 0, 'Teknik Industri', NULL, NULL, '2022-03-24 12:55:25', '2022-03-24 12:55:25');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `simulasi_penilaians`
--
ALTER TABLE `simulasi_penilaians`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `simulasi_penilaians`
--
ALTER TABLE `simulasi_penilaians`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
