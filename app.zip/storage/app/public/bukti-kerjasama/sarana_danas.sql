-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 24 Mar 2022 pada 06.12
-- Versi server: 5.7.33
-- Versi PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tes`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `sarana_danas`
--

CREATE TABLE `sarana_danas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sarana_id` bigint(20) UNSIGNED NOT NULL,
  `biaya_id` bigint(20) UNSIGNED DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_pengelola_ts` int(11) DEFAULT NULL,
  `unit_pengelola_average` double(8,2) DEFAULT NULL,
  `ps_ts` int(11) DEFAULT NULL,
  `ps_average` double(8,2) DEFAULT NULL,
  `tahun_laporan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prodi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sarana_danas`
--

INSERT INTO `sarana_danas` (`id`, `sarana_id`, `biaya_id`, `code`, `unit_pengelola_ts`, `unit_pengelola_average`, `ps_ts`, `ps_average`, `tahun_laporan`, `prodi`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'A', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(2, 1, 1, 'A', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(3, 1, 1, 'A', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(4, 1, 2, 'B', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(5, 1, 2, 'B', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(6, 1, 2, 'B', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(7, 1, 3, 'C', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(8, 1, 3, 'C', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(9, 1, 3, 'C', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(10, 1, 4, 'D', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(11, 1, 4, 'D', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(12, 1, 4, 'D', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(13, 2, NULL, 'E', 12, NULL, 12, NULL, '2018', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-23 17:39:34', '2022-03-23 17:39:34'),
(14, 2, NULL, 'E', 12, NULL, 12, NULL, '2019', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-23 17:39:34', '2022-03-23 17:39:34'),
(15, 2, NULL, 'E', NULL, 8.00, 12, 12.00, '2020', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-23 17:39:34', '2022-03-23 17:39:34'),
(16, 3, NULL, 'E', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(17, 3, NULL, 'E', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(18, 3, NULL, 'E', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(19, 4, NULL, 'F', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(20, 4, NULL, 'F', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(21, 4, NULL, 'F', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(22, 5, NULL, 'G', 12, NULL, 12, NULL, '2018', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-24 06:05:46', '2022-03-24 06:05:46'),
(23, 5, NULL, 'G', 12, NULL, 12, NULL, '2019', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-24 06:05:46', '2022-03-24 06:05:46'),
(24, 5, NULL, 'G', NULL, 8.00, 12, 12.00, '2020', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-24 06:05:46', '2022-03-24 06:05:46'),
(25, 6, NULL, 'H', NULL, NULL, NULL, NULL, '2018', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(26, 6, NULL, 'H', NULL, NULL, NULL, NULL, '2019', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(27, 6, NULL, 'H', NULL, NULL, NULL, NULL, '2020', 'Teknik Industri', NULL, NULL, '2022-03-23 17:39:22', '2022-03-23 17:39:22'),
(28, 7, NULL, 'I', 12, NULL, 12, NULL, '2018', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-23 17:49:25', '2022-03-23 17:49:25'),
(29, 7, NULL, 'I', 12, NULL, 12, NULL, '2019', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-23 17:49:25', '2022-03-23 17:49:25'),
(30, 7, NULL, 'I', NULL, 8.00, 12, 12.00, '2020', 'Teknik Industri', 'Teknik Industri', NULL, '2022-03-23 17:49:25', '2022-03-23 17:49:25');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `sarana_danas`
--
ALTER TABLE `sarana_danas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `sarana_danas`
--
ALTER TABLE `sarana_danas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
