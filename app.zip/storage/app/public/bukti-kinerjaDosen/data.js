let r = 0;
let x = []; x[0] = 0.5;
let es = 0.00001;

do {
    x[r+1] = (x[r] + 3) / 6;
    r++;
    console.log("data: ",x[r+1]);
} while (x [r+1] == es);