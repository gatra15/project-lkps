<div class="tab-pane fade show" id="integrasi" role="tabpanel">
    <p class="d-flex justify-content-between">
        <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
            Deskripsi
        </a>
        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalintegrasi">
            Tambah data
        </button>
        <?php endif; ?>
    </p>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('download file')): ?>
    <a href="/pendidikan/integrasi/download/excel" class="btn btn-success">Excel</a>
    <a href="/pendidikan/integrasi/download/csv" class="btn btn-success">CSV</a>
    <input type="button" class="btn btn-primary" onclick="printDiv('print-table')" value="Print Document" />
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#caradownload">
        Cara Download PDF
    </button>
    <?php endif; ?>
    <div class="collapse" id="collapseExample">
    <div class="card card-body">
        <p>
            Tuliskan judul penelitian/PkM DTPS yang terintegrasi ke dalam pembelajaran/
            pengembangan matakuliah dalam 3 tahun terakhir dengan mengikuti format Tabel
            berikut ini. <br> <br>
            <b>Keterangan</b> <br>
            1) Judul penelitian dan PkM tercatat di unit/lembaga yang mengelola kegiatan
            penelitian/PkM di tingkat Perguruan Tinggi/UPPS. <br>
            2) Bentuk integrasi dapat berupa tambahan materi perkuliahan, studi kasus, Bab/
            Subbab dalam buku ajar, atau bentuk lain yang relevan. <br>
        </p>
    </div> 
    </div>

          <!-- Modal Tambah Data Integritas -->
          <div class="modal fade" id="modalintegrasi" tabindex="-1" aria-labelledby="modalintegrasi" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalintegrasi">Tambah Data Integrasi Kegiatan Penelitian/PkM dalam Pembelajaran </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <?php echo $__env->make('partials.pendidikanmodal.integrasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
            </div>
            
            <?php echo $__env->make('tab.pendidikantab.integrasitable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            <?php $__currentLoopData = $integrasi['integrasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $integrasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- Modal Tambah Edit Integritas -->
          <div class="modal fade" id="modalintegrasiedit-<?php echo e($integrasi->id); ?>" tabindex="-1" aria-labelledby="modalintegrasiedit" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalintegrasiedit">Edit Data Integrasi Kegiatan Penelitian/PkM dalam Pembelajaran </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <?php echo $__env->make('partials.pendidikanmodal.integrasiedit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
            </div>

          <!-- Modal Tambah Delete Integritas -->
          <div class="modal fade" id="modalintegrasidelete-<?php echo e($integrasi->id); ?>" tabindex="-1" aria-labelledby="modalintegrasidelete" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalintegrasidelete">Delete Data Integrasi Kegiatan Penelitian/PkM dalam Pembelajaran </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <?php echo $__env->make('partials.pendidikanmodal.integrasidelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
<?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/tab/pendidikantab/integrasi.blade.php ENDPATH**/ ?>