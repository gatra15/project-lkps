<form action="/penelitian/<?php echo e($penelitian->id); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                
                
                <label for="lembaga">Nama Dosen : </label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="nama_dosen" value="<?php echo e($penelitian->nama_dosen); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="lembaga"> Tema Penelitian ( Sesuai Roadmap ) :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="tema" value="<?php echo e($penelitian->tema); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="lembaga"> Nama Mahasiswa :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="nama_mahasiswa" value="<?php echo e($penelitian->nama_mahasiswa); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="lembaga"> Judul Kegiatan :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="judul" value="<?php echo e($penelitian->judul); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="lembaga"> Tahun :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="number" min="2000" max="2050" name="tahun" value="<?php echo e($penelitian->tahun); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
               

            
            
               

            </div>
        </div>
    
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary">Update</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/penelitianmodal/penelitianedit.blade.php ENDPATH**/ ?>