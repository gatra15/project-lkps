<div id="print-table6">
    <table id='form-print' class="table text-center table-bordered table-condensed">
    <thead>
    <tr>
    <th class="align-middle text-center" scope="col" rowspan="2">Tahun Lulus</th>
    <th class="align-middle text-center" scope="col" rowspan="2">Jumlah <br> Lulusan </th>
    <th class="align-middle text-center" scope="col" rowspan="2">Jumlah <br> Lulusan <br> yang <br> Terlacak</th>
    <th class="align-middle text-center" scope="col" colspan="3">Jumlah Lulusan Terlacak dengan <br>
        Tingkat Kesesuaian Bidang Kerja</th>
        <th class="align-middle text-center" scope="col" rowspan="2">Opsi</th>
    </tr>
    <tr>
    <th scope="col">Rendah <sup>1)</sup></th>
    <th scope="col">Sedang <sup>2)</sup></th>
    <th scope="col">Tinggi <sup>3)</sup></th>
    </tr>
    
    </thead>
    
    <tbody class="text-dark">
        <?php $__currentLoopData = $kesesuaianBidang['bidang']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kesesuaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key == sizeof($kesesuaianBidang['bidang'])-1 ? 'TS-2' : 'TS-'.(sizeof($kesesuaianBidang['bidang'])+1-$key)); ?></td>
            <td><?php echo e($kesesuaian->jumlah_lulusan); ?></td>
            <td><?php echo e($kesesuaian->jumlah_lulusan_terlacak); ?></td>
            <td><?php echo e($kesesuaian->kesesuaian_rendah); ?></td>
            <td><?php echo e($kesesuaian->kesesuaian_sedang); ?></td>
            <td><?php echo e($kesesuaian->kesesuaian_tinggi); ?></td>
            <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
            <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                <li><a type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalkesesuaianedit-<?php echo e($kesesuaian->id); ?>"><i class="fas fa-edit"></i></a></li>
                <li>
                    <a type="button" class="btn btn-danger" href="/luaran-capaian-tridharma/kesesuaian-bidang/<?php echo e($kesesuaian->id); ?>" data-toggle="modal" data-target="#modalkesesuaiandelete-<?php echo e($kesesuaian->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
            </ul></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table> 
    </div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/luarantab/kesesuaiantable.blade.php ENDPATH**/ ?>