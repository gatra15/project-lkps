<div id="print-table">
    <table id='form-print' class="table text-center table-bordered table-condensed">
        <thead>
            <tr>

                <th class="align-middle" scope="col" rowspan="2">No</th>
                <th class="align-middle" scope="col" rowspan="2">Nama Dosen</th>
                <th class="align-middle" scope="col" rowspan="2">Judul Artikel yang Disitasi (Jurnal/Buku,Volume, Tahun, Nomor,Halaman)</th>
                <th class="align-middle" scope="col" rowspan="2" >Jumlah Sitasi</th>       
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>             
                <th class="align-middle" scope="col" rowspan="2" >Opsi</th>               
                <?php endif; ?>     
            </tr>


        </thead>

        <tbody class="text-dark">
            <?php $__currentLoopData = $karyailmiah['karyailmiah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($karil->nama_dosen); ?></td> 
            <td><?php echo e($karil->judul); ?></td> 
            <td><?php echo e($karil->jumlah_sitasi); ?></td> 
            <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
            <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalkaryailmiahedit-<?php echo e($karil->id); ?>"><i class="fas fa-edit"></i></a></li>
                <li>
                    <a type="button" class="btn btn-danger" href="/kinerja-dosen/karya-ilmiah/<?php echo e($karil->id); ?>" data-toggle="modal" data-target="#modalkaryailmiahdelete-<?php echo e($karil->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
            </ul></td>
            <?php endif; ?>
            </tr>

        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td colspan="2"><b>Jumlah</b></td>
            <td><?php echo e($karyailmiah['count']); ?></td>
            <td><?php echo e($karyailmiah['jumlah']); ?></td>
            <td></td>
        </tr>
        </table> 
    </div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/kinerjadosentab/karyailmiahdtpstable.blade.php ENDPATH**/ ?>