<div id="print-table">
    <table class="table table-bordered table-condensed">
    <thead>
    
    <tr>
    <th scope="col">No</th>
    <th scope="col">Judul Penelitian/PkM <sup>1)</sup>  </th>
    <th scope="col">Nama Dosen</th>
    <th scope="col">Mata Kuliah</th>
    <th scope="col">Bentuk Integrasi <sup>2)</sup></th>
    <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
    <th scope="col">Opsi</th>
    <?php endif; ?>
    </tr>
    
    </thead>
    
    <tbody>
    
    <?php $__currentLoopData = $integrasi['integrasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $integrasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($integrasi->judul); ?></td>
            <td><?php echo e($integrasi->nama_dosen); ?></td>
            <td><?php echo e($integrasi->mata_kuliah); ?></td>
            <td><?php echo e($integrasi->bentuk_integrasi); ?></td>
            <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
            <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                <li><a type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalintegrasiedit-<?php echo e($integrasi->id); ?>"><i class="fas fa-edit"></i></a></li>
                <li>
                    <a type="button" class="btn btn-danger" href="/pendidikan/integrasi/<?php echo e($integrasi->id); ?>" data-toggle="modal" data-target="#modalintegrasidelete-<?php echo e($integrasi->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
            </ul></td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table> 
</div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/pendidikantab/integrasitable.blade.php ENDPATH**/ ?>