<div id="print-table2">
    <table class="table table-bordered table-condensed">
    <thead>
    
    <tr>
        <th class="text-center align-middle" scope="col" rowspan="2">No</th>
        <th class="text-center align-middle" scope="col" rowspan="2">Aspek yang Diukur</th>
        <th class="text-center align-middle" scope="col" colspan="4">Tingkat Kepuasan Mahasiswa (%)</th>
        <th class="text-center align-middle" scope="col" rowspan="2">Rencana Tindak Lanjut oleh UPPS/PS</th>
        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
        <th class="text-center align-middle" scope="col" rowspan="2">Opsi</th>
        <?php endif; ?>
    </tr>
    
    <tr>
        <th class="text-center align-middle" scope="col">Sangat Baik</th>
        <th class="text-center align-middle" scope="col">Baik</th>
        <th class="text-center align-middle" scope="col">Cukup</th>
        <th class="text-center align-middle" scope="col">Kurang</th>
    </tr>
    </thead>
    
    <tbody>
        <?php $__currentLoopData = $kepuasanmahasiswa['kepuasan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepuasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo $kepuasan->aspek->aspek ?></td>
                <td><?php echo e($kepuasan->sangat_baik); ?></td>
                <td><?php echo e($kepuasan->baik); ?></td>
                <td><?php echo e($kepuasan->cukup); ?></td>
                <td><?php echo e($kepuasan->kurang); ?></td>
                <td><?php echo e($kepuasan->rencana_tindak_lanjut); ?></td>
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalkepuasanedit-<?php echo e($kepuasan->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/pendidikan/kepuasan-mahasiswa/<?php echo e($kepuasan->id); ?>" data-toggle="modal" data-target="#modalkepuasandelete-<?php echo e($kepuasan->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="align-middle text-center"><b>Jumlah</b></td>
            <td></td>
            <td class="putih"><?php echo e($kepuasanmahasiswa['sangat_baik']); ?></td>
            <td class="putih"><?php echo e($kepuasanmahasiswa['baik']); ?></td>
            <td class="putih"><?php echo e($kepuasanmahasiswa['cukup']); ?></td>
            <td class="putih"><?php echo e($kepuasanmahasiswa['kurang']); ?></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    
    </tbody>
    </table> 
</div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/pendidikantab/kepuasantable.blade.php ENDPATH**/ ?>