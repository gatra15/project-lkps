<form action="/luaran-capaian-tridharma/capaian/<?php echo e($capaian->id); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                

                <label for="dosentetap"> Tahun Akademik :</label>
                <label for="capaianpembelajaran"> Jumlah Lulusan :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="jumlah_lulusan" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="lembaga" class="fs-6 my-2"> Indeks Prestasi Kumulatif </label>
                <div class="form-row justify-content-center">
                    <div class="form-group col-md-6 align-middle">
                      <label for="#">Min.</label>
                      <div class="input-group input-group-sm mb-3">
                      <input type="text" class="form-control mb-3" value="<?php echo e($capaian->ipk_min); ?>" name="ipk_min" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                      </div>
                    </div>
                    <div class="form-group col-md-6 align-middle">
                      <label for="#">Max.</label>
                      <div class="input-group input-group-sm mb-3">
                      <input type="text" class="form-control mb-3" value="<?php echo e($capaian->ipk_max); ?>" name="ipk_max" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                      </div>
                    </div>
                  </div>
                <label for="capaianpembelajaran"> Rata-rata :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="ipk_avg" value="<?php echo e($capaian->ipk_avg); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>  
                
                

               
               

            </div>
        </div>
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/luarancapaianmodal/capaianedit.blade.php ENDPATH**/ ?>