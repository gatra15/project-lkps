<form action="/profil-dosen/<?php echo e($sdm->id); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                

                <label for="dosentetap"> Nama Dosen :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="nama_dosen" value="<?php echo e($sdm->nama_dosen); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                <label for="dosentetap"> NIDN / NIDK :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="nidn_nidk" value="<?php echo e($sdm->nidn_nidk); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Pendidikan Magister / Magister Terapan / Spesialis :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="pendidikan_pasca_sarjana_magister" class="form-control" value="<?php echo e($sdm->pendidikan_pasca_sarjana_magister); ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Pendidikan Doktor / Doktor Terapan / Spesialis :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="pendidikan_pasca_sarjana_doktor" value="<?php echo e($sdm->pendidikan_pasca_sarjana_doktor); ?>"class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Bidang Keahlian :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="bidang_keahlian" value="<?php echo e($sdm->bidang_keahlian); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Kesesuaian dengan Kompetensi Inti PS :</label>
                <div class="input-group mb-3">
                    <select class="custom-select" name="kesesuaian_ps" id="inputGroupSelect01">
                        <option >pilih...</option>
                        <option <?php echo e($sdm->kesesuaian_ps == '1' ? 'selected' : ''); ?> value="1">Iya</option>
                        <option <?php echo e($sdm->kesesuaian_ps == '0' ? 'selected' : ''); ?> value="0">Tidak</option>
                    </select>
                </div>
                <label for="dosentetap"> Jabatan Akademik :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="jabatan_akademik" value="<?php echo e($sdm->jabatan_akademik); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Sertifikat Pendidik Profesional :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="sertifikat_pendidik_profesi" value="<?php echo e($sdm->sertifikat_pendidik_profesi); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Sertifikat Kompetensi / Profesi / Industri :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="sertifikat_kompetensi" value="<?php echo e($sdm->sertifikat_kompetensi); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Mata Kuliah yang Diampu pada PS yang Diakreditasi :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="mata_kuliah_akreditasi_diampu" value="<?php echo e($sdm->mata_kuliah_akreditasi_diampu); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="dosentetap"> Kesesuaian Bidang Keahlian dengan Mata Kuliah yang Diampu :</label>
                <div class="input-group mb-3">
                    <select class="custom-select" name="kesesuaian_mata_kuliah_diampu" id="inputGroupSelect01">
                        <option >pilih...</option>
                        <option <?php echo e($sdm->kesesuaian_mata_kuliah_diampu == '1' ? 'selected' : ''); ?> value="1">Iya</option>
                        <option <?php echo e($sdm->kesesuaian_mata_kuliah_diampu == '0' ? 'selected' : ''); ?> value="0">Tidak</option>
                    </select>
                </div>
                <label for="dosentetap"> Mata Kuliah yang Diampu pada PS Lain :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="mata_kuliah_diampu_ps_lain" value="<?php echo e($sdm->mata_kuliah_diampu_ps_lain); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>

               

            </div>
        </div>
    
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary">Tambah</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/profildosenmodal/dosentetapedit.blade.php ENDPATH**/ ?>