<form action="<?php echo e(url('//tata-pamong-tata-kelola-kerjasama')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                
                
                <label for="lembaga"> Tridharma :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="tridharma" value="Pengabdian Kepada Masyarakat" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" readonly>
                </div>
                <label for="lembaga"> Lembaga Mitra :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="lembaga_mitra" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                <label for="lembaga"> Tingkat :</label>
                <div class="input-group mb-3">
                    <select class="custom-select" name="tingkat" id="inputGroupSelect01">
                        <option selected>pilih...</option>
                        <option value="Internasional">Internasional</option>
                        <option value="Nasional">Nasional</option>
                        <option value="Lokal">Lokal</option>
                    </select>
                </div>
                <label for="lembaga"> Judul Kegiatan Bersama :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="judul_kegiatan" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                <label for="lembaga"> Manfaat Bagi PS yang Diakreditasi :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="manfaat" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                <label for="lembaga"> Waktu dan Durasi :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="waktu_durasi" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                <label for="lembaga"> Bukti Kerjasama :</label>
                <div class="input-group mb-3">
                <div class="custom-file">
                    <input type="file" name="bukti_kerjasama" class="custom-file-input" id="inputGroupFile02">
                    <label class="custom-file-label" for="inputGroupFile02" aria-describedby="Upload">Pilih File</label>
                </div>
                </div>
               

            
            
               

            </div>
        </div>
    
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary">Tambah</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/tatapamongmodal/pkm.blade.php ENDPATH**/ ?>