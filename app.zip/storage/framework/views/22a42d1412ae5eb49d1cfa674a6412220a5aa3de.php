<form action="/pendidikan/kepuasan-mahasiswa/<?php echo e($kepuasan->id); ?>" method="post">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <h5 class="text-center">Yakin Ingin Menghapus ? </h5>
        <input type="hidden" name="aspek_id" value="<?php echo e($kepuasan->aspek_id); ?>">
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-danger">Yakin</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/pendidikanmodal/kepuasandelete.blade.php ENDPATH**/ ?>