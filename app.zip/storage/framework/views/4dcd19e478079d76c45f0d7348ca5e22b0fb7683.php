<form action="/mahasiswa/delete/<?php echo e($mhs->id); ?>" method="post">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <h5 class="text-center">Yakin ingin menghapus data Mahasiswa pada? </h5>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-danger">Yakin</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/mahasiswamodal/mahasiswadelete.blade.php ENDPATH**/ ?>