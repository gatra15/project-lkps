<form action="/tata-pamong-tata-kelola-kerjasama/<?php echo e($indikator->id); ?>" method="post">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('get'); ?>
        <h5 class="text-center">Yakin Ingin Delete <?php echo e($indikator->tridharma); ?> dengan lembaga <?php echo e($indikator->lembaga_mitra); ?>? </h5>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-danger">Yakin</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/tatapamongmodal/penelitiandelete.blade.php ENDPATH**/ ?>