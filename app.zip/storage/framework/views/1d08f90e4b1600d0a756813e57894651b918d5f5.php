<div class="tab-pane fade show" id="prestasi" role="tabpanel" aria-labelledby="prestasi-tab">
    <p class="d-flex justify-content-between">
        <a class="btn btn-primary" data-toggle="collapse" href="#des2" role="button" aria-expanded="false" aria-controls="des2">
            Deskripsi
        </a>
        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalluaranprestasi">
            Tambah data
        </button>
        <?php endif; ?>
    </p>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('download file')): ?>
    <input type="button" class="btn btn-primary" onclick="printDiv('print-table8')" value="Print Document" />
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#caradownload">
        Cara Download PDF
    </button>
    <?php endif; ?>
    <div class="collapse" id="des2">
        <div class="card card-body">
            <p>
                Tuliskan prestasi akademik/non-akademik yang dicapai mahasiswa Program Studi <b> dalam 5 tahun terakhir </b> dengan mengikuti format Tabel berikut ini. Data dilengkapi dengan keterangan kegiatan yang diikuti (nama kegiatan, tahun, tingkat, dan prestasi yang dicapai). <br>
            </p>
        </div> 
    </div>

     <!-- Modal Tambah Data Prestasi -->
     <div class="modal fade" id="modalluaranprestasi" tabindex="-1" aria-labelledby="modalluaranprestasi" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modalluaranprestasi">Tambah Data Prestasi Mahasiswa </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.luarancapaianmodal.prestasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        </div>

        
        <?php echo $__env->make('tab.luarantab.prestasitable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <?php $__currentLoopData = $prestasi['prestasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Modal Tambah Edit Prestasi -->
      <div class="modal fade" id="modalluaranprestasiedit-<?php echo e($prest->id); ?>" tabindex="-1" aria-labelledby="modalluaranprestasiedit" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modalluaranprestasiedit">Update Data Prestasi Mahasiswa </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.luarancapaianmodal.prestasiedit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        </div>

      <!-- Modal Tambah Delete Prestasi -->
      <div class="modal fade" id="modalluaranprestasidelete-<?php echo e($prest->id); ?>" tabindex="-1" aria-labelledby="modalluaranprestasidelete" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modalluaranprestasidelete">Hapus Data Prestasi Mahasiswa </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.luarancapaianmodal.prestasidelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/luarantab/prestasi.blade.php ENDPATH**/ ?>