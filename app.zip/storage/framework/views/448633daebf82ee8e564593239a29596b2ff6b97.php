


<?php $__env->startSection('content'); ?>


<div class="content-header">
    <div class="container-fluid">
            <h1>TAB KINERJA DOSEN</h1>
    </div>
</div>


<div class="content">
    <div class="container-fluid">
        <div class="card">
          <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
          <?php endif; ?>

          <?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger">
              <strong><?php echo e($message); ?></strong>
          </div>
            <?php endif; ?>

    
    <div class="card-header">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="pengakuan-tab" data-toggle="tab" href="#pengakuan" role="tab" aria-controls="pengakuan" aria-selected="true">Pengakuan/Rekognisi DTPS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="penelitian-tab" data-toggle="tab" href="#penelitian" role="tab" aria-controls="penelitian" aria-selected="false">Penelitian DTPS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="pengabdian-tab" data-toggle="tab" href="#pengabdian" role="tab" aria-controls="pengabdian" aria-selected="false">Pengabdian kepada Masyarakat (PkM) DTPS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="publikasi-tab" data-toggle="tab" href="#publikasi" role="tab" aria-controls="publikasi aria-selected="false">Publikasi Ilmiah DTPS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="karya-tab" data-toggle="tab" href="#karya" role="tab" aria-controls="karya" aria-selected="false">Karya ilmiah DTPS yang disitasi dalam 3 tahun terakhir</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="luaran-tab" data-toggle="tab" href="#luaran" role="tab" aria-controls="luaran" aria-selected="false">Luaran Penelitian/PkM Lainnya oleh DTPS</a>
            </li>
        </ul>
    </div>

    
    <div class="card-body">
        <div class="tab-content mt-3">
            <div class="tab-content" id="myTabContent">

                
                
    
    <?php echo $__env->make('tab.kinerjadosentab.pengakuandtps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    

    
     <?php echo $__env->make('tab.kinerjadosentab.penelitiandtps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
    

    
    <?php echo $__env->make('tab.kinerjadosentab.pkm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    
    <?php echo $__env->make('tab.kinerjadosentab.publikasidtps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    
    
    
    <?php echo $__env->make('tab.kinerjadosentab.karyailmiahdtps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    
    
    
    <?php echo $__env->make('tab.kinerjadosentab.luarandtps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    
        </div>
        </div>
        </div>
    </div>
    </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/tab/kinerjadosentab/kinerjaDosen.blade.php ENDPATH**/ ?>