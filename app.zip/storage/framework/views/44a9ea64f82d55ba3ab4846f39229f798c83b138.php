<div id="print-table">
    <table id='form-print' class="table text-center table-bordered table-condensed">
        <thead>
            <tr>
                <th class="align-middle" scope="col" rowspan="2">No</th>
                <th class="align-middle" scope="col" rowspan="2">Nama Dosen</th>
                <th class="align-middle" scope="col" rowspan="2">Tema PkM Sesuai Roadmap</th>
                <th class="align-middle" scope="col" rowspan="2">Nama Mahasiswa</th>
                <th class="align-middle" scope="col" rowspan="2">Judul Kegiatan <sup>1)</sup></th>
                <th class="align-middle" scope="col" rowspan="2">Tahun</th>
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <th class="align-middle" scope="col" rowspan="2">Opsi</th>
                <?php endif; ?>

            </tr>
    
        </thead>

        <tbody class="text-dark">
            <?php $__currentLoopData = $pengabdian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pkm->nama_dosen); ?></td>
                    <td><?php echo e($pkm->tema); ?></td>
                    <td><?php echo e($pkm->nama_mahasiswa); ?></td>
                    <td><?php echo e($pkm->judul_kegiatan); ?></td>
                    <td><?php echo e($pkm->tahun); ?></td>
                    <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                    <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                        <li><a type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalpkmedit-<?php echo e($pkm->id); ?>"><i class="fas fa-edit"></i></a></li>
                        <li>
                            <a type="button" class="btn btn-danger" href="/pkm/<?php echo e($pkm->id); ?>" data-toggle="modal" data-target="#modalpkmdelete-<?php echo e($pkm->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                    </ul></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td class="align-middle text-center" colspan="4"><b>Jumlah</b></td>
                <td><?php echo e($jumlah_judul); ?></td>
            </tr>
    </table> 
</div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/pkmtab/pkmtable.blade.php ENDPATH**/ ?>