<form action="/kinerja-dosen/pkm-dtps/<?php echo e($ts->tahun_laporan); ?>/<?php echo e($ts->sumber_id); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                
                <label for="dosentetap"> Sumber Daya Pembiyaan :</label>
                <p><?php echo $ts->sumber->sumberdaya ?></p>
                <div class="input-group input-group-sm mb-3">
                    <input type="hidden" name="sumber_id" value="<?php echo e($ts->sumber_id); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" readonly>
                </div>

                <label for="penelitian" class="fs-6 my-2"> Jumlah Judul </label>
                <div class="form-row justify-content-center text-center">
                    <div class="form-group col-md-4 align-middle">
                    <label for="dosentetap"> TS-2 :</label>
                    <?php if($ts->sumber_id == 1): ?>
                        <?php $__currentLoopData = $pkms['ts2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input name="jumlah_ts2" value="<?php echo e($ts2->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif($ts->sumber_id == 2): ?>
                        <?php $__currentLoopData = $pkms['ts2_sumber2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input name="jumlah_ts2" value="<?php echo e($ts2->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $pkms['ts2_sumber3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input name="jumlah_ts2" value="<?php echo e($ts2->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                       
                    </div>
                    <div class="form-group col-md-4 align-middle">
                        <label for="dosentetap"> TS-1 :</label>
                        <?php if($ts->sumber_id == 1): ?>
                            <?php $__currentLoopData = $pkms['ts1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input name="jumlah_ts1" value="<?php echo e($ts1->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif($ts->sumber_id == 2): ?>
                            <?php $__currentLoopData = $pkms['ts1_sumber2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input name="jumlah_ts1" value="<?php echo e($ts1->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $pkms['ts1_sumber3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input name="jumlah_ts1" value="<?php echo e($ts1->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </div>
                    <div class="form-group col-md-4 align-middle">
                        <label for="dosentetap"> TS :</label>
                        <?php if($ts->sumber_id == 1): ?>
                            <?php $__currentLoopData = $pkms['ts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input name="jumlah_ts" value="<?php echo e($ts->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif($ts->sumber_id == 2): ?>
                            <?php $__currentLoopData = $pkms['ts_sumber2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input name="jumlah_ts" value="<?php echo e($ts->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $pkms['ts_sumber3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input name="jumlah_ts" value="<?php echo e($ts->jumlah_ts); ?>" class="form-control form-control-sm mb-3" type="number" min="1" required>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                    </div>
                </div>

               
               

            </div>
        </div>
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/kinerjadosenmodal/pkmedit.blade.php ENDPATH**/ ?>