<div id="print-table6">
    <table id='form-print' class="table table-inverse text-center table-bordered table-condensed">
        <thead>
            <tr>

                <th class="align-middle" scope="col" rowspan="2">No</th>
                <th class="align-middle" scope="col" rowspan="2">Jenis</th>
                <th scope="col" colspan="3">Jumlah Judul</th>
                <th class="align-middle" scope="col" rowspan="2" >Jumlah</th>   
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>                 
                <th class="align-middle" scope="col" rowspan="2" >Opsi</th>     
                <?php endif; ?>               
            </tr>
            <tr>
                <th scope="col">TS-2</th>
                <th scope="col">TS-1</th>
                <th scope="col">TS</th>
            </tr>

        </thead>
        <tbody>
            <?php $__currentLoopData = $publikasi['ts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media8']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media8']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media8']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media8']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media9']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media9']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media9']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media9']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
            <?php $__currentLoopData = $publikasi['ts_media10']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>1</td>
                <td>
                    <?php echo $ts->media->media ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <?php $__currentLoopData = $publikasi['ts2_media10']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts2->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts1_media10']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts1->jumlah_ts); ?></td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $publikasi['ts_media10']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($ts->jumlah_ts); ?></td> 
                <td><?php echo e($ts->jumlah); ?></td> 
                <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                <td style="align-middle text-center"><ul class="action-list d-flex justify-content-center mr-1 align-middle" id="action">
                    <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalpublikasiedit-<?php echo e($ts->id); ?>"><i class="fas fa-edit"></i></a></li>
                    <li>
                        <a type="button" class="btn btn-danger" href="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->id); ?>" data-toggle="modal" data-target="#modalpublikasidelete-<?php echo e($ts->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                </ul></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
        
        <tr>
            <td colspan="2" class="text-center"><b>Total</b></td>
            <td><?php echo e($publikasi['jumlah_ts2']); ?></td>
            <td><?php echo e($publikasi['jumlah_ts1']); ?></td>
            <td><?php echo e($publikasi['jumlah_ts']); ?></td>
            <td><?php echo e($publikasi['jumlah']); ?></td>
            <td></td>
        </tr>

    </tbody>
    </table> 
</div><?php /**PATH C:\laragon\www\lkps\resources\views/tab/kinerjadosentab/publikasitable.blade.php ENDPATH**/ ?>