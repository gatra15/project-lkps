<form action="/kinerja-dosen/luaran-dtps/<?php echo e($data->id); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                
                <div class="input-group input-group-sm mb-3">
                    <input type="hidden" name="type_luaran" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($data->type_luaran); ?>" required>
                </div>
                <label for="pengkuan"> Judul :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="judul" value="<?php echo e($data->judul); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="pengkuan"> Tahun:</label>
                <div class="input-group input-group-sm mb-3">
                    <select class="custom-select" name="tahun" value="<?php echo e($data->tahun); ?>" id="inputGroupSelect01">
                <?php
                    $years = range(2000, strftime("%Y", time()));
                ?>
                <option ><?php echo e($data->tahun); ?></option>
                <?php foreach($years as $year) : ?>
                    <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                <?php endforeach; ?>
                    </select>
                </div>
                <label class="kanan"> Keterangan: </label>
                <div class="form">
                    <textarea class="form-control" type="text" name="keterangan" placeholder="" id="floatingTextarea2" style="height: 200px" required> <?php echo e($data->keterangan); ?> </textarea>
                </div>
                <label for="lembaga" class="mt-3"> Bukti  :</label>
                <div class="input-group input-group-sm mb-3">
                <input type="file" name="bukti" value="" class="form-control" id="customFile" required>
                </div>
                <div class="form-text" style="color: red">Ganti File, Atau Kosongkan bila tidak perlu di ganti</div>
                

               
               

            </div>
        </div>
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-primary">Update</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/kinerjadosenmodal/luaranedit.blade.php ENDPATH**/ ?>