<form action="/user/<?php echo e($users->id); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        
        <div class="card-body px-20 pb-20">
            <div class="row">
               
                
                
                <label for="pengkuan"> Nama : </label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="name" class="form-control" value="<?php echo e($users->name); ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="pengkuan"> Email :</label>
                <div class="input-group input-group-sm mb-3">
                    <input type="text" name="email" value="<?php echo e($users->email); ?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" required>
                </div>
                <label for="pengkuan"> Role :</label>
                <div class="input-group input-group-sm mb-3">
                    <select id="role" name="role" class="form-control form-control-lg mb-3" aria-label=".form-control-lg">
                        <option>Pilih Role</option>
                       <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($users->role == $roles->name ? 'selected' : ''); ?> value="<?php echo e($roles->name); ?>"><?php echo e($roles->name); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <label for="pengkuan"> Prodi :</label>
                
                <div class="input-group input-group-sm mb-3">
                    <select id="prodi" name="prodi_id" class="form-control form-control-lg mb-3" aria-label=".form-control-lg">
                        <option>Pilih prodi</option>
                        
                       <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                       <?php if($users->prodi != null): ?>
                       <option <?php echo e($users->prodi->name == $prodis->name ? 'selected' : ''); ?> value="<?php echo e($prodis->id); ?>"><?php echo e($prodis->name); ?></option>
                       <?php else: ?>
                       <option value="<?php echo e($prodis->id); ?>"><?php echo e($prodis->name); ?></option>
                       <?php endif; ?>
                        
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
               
               

            </div>
        </div>
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </div>
</form>

<?php /**PATH C:\laragon\www\lkps\resources\views/partials/modaladmin/useredit.blade.php ENDPATH**/ ?>