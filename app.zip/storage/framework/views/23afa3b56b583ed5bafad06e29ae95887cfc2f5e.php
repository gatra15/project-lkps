


<?php $__env->startSection('content'); ?>
<style>
    table.table-bordered{
        border:1px solid black;
        margin-top:20px;
      }
    table.table-bordered > thead > tr > th{
        border:1px solid black;
    }
    table.table-bordered > tbody > tr > td{
        border:1px solid black;
    }
    
    table thead tr th.putih {
        background-color: white;
        border-bottom: 3px solid black;
    }
    </style> 
    
    
    <div class="content-header">
        <div class="container-fluid">
                <h1>User Access</h1>
        </div>
    </div>
    
    
    <div class="content">
    <div class="container-fluid">
            <div class="card">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
        
                <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
    <div class="card-header">
        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link  active" id="kualitas-tab" data-toggle="tab" href="#kualitas" role="tab" aria-controls="kualitas" aria-selected="true">List User</a>
            </li>
          </ul>
          
    </div>
    <div class="card-body">
        <div class="tab-content mt-3">
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="kualitas" role="tabpanel" aria-labelledby="kualitas-tab">
                <p class="d-flex justify-content-end">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modaluser">
                        Tambah Data
                    </button>
                </p>
                <div class="input-group input-group-sm rounded align-right" style = "padding: 1px 1px 1px 600px;">
                    <input  width="20%" type="search" class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                    <button type="button" class="btn btn-outline-primary">search</button>
                  </div>
    

      <!-- Modal Tambah Data -->
        <div class="modal fade" id="modaluser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah User</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.modaladmin.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
        </div>  

        <table class="table text-center table-bordered">
            <thead class="align-middle">
                <tr>
                    <th class="putih" scope="col" width="1%">No</th>
                    <th class="putih" scope="col" width="35%">Nama</th>
                    <th class="putih" scope="col" width="30%">Email</th>
                    <th class="putih" scope="col" width="20%">Role</th>
                    <th class="putih" scope="col" width="24%">Action</th>
                </tr>
       
            </thead>
    
            <tbody class="text-dark">
              
              
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($users->name); ?></td>
                    <td><?php echo e($users->email); ?></td>
                    <td><?php echo e($users->role == '' ? $users->getRoleNames() : $users->role); ?> </td>         
                    <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                        <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modaluseredit-<?php echo e($users->id); ?>"><i class="fas fa-edit"></i></a></li>
                        <li>
                            <a type="button" class="btn btn-danger" href="/user/<?php echo e($users->id); ?>" data-toggle="modal" data-target="#modaluserdelete-<?php echo e($users->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                    </ul></td>
                </tr>
               
    
             <!-- Modal Edit Data -->
             
            <div class="modal fade" id="modaluseredit-<?php echo e($users->id); ?>" tabindex="-1" aria-labelledby="modaluseredit" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modaluseredit">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <?php echo $__env->make('partials.modaladmin.useredit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                </div>
            </div>  

        <!-- Modal Hapus Data -->
        <div class="modal fade" id="modaluserdelete-<?php echo e($users->id); ?>" tabindex="-1" aria-labelledby="modaluserdelete" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modaluserdelete">Hapus User</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.modaladmin.userdelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
        </div>     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> 
    
        
                </div>
              </div>
        </div>
    </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sideadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/admin/index.blade.php ENDPATH**/ ?>