    
    <div class="tab-pane fade" id="karya" role="tabpanel" aria-labelledby="karya-tab">
        <p class="d-flex justify-content-between">
            <a class="btn btn-primary" data-toggle="collapse" href="#des5" role="button" aria-expanded="false" aria-controls="des5">
                Deskripsi
            </a>
            <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalkaryailmiah">
                Tambah data
            </button>
            <?php endif; ?>
        </p>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('download file')): ?>
    <a href="/kinerja-dosen/karya-ilmiah/download/excel" class="btn btn-success">Excel</a>
    <a href="/kinerja-dosen/karya-ilmiah/download/csv" class="btn btn-success">CSV</a>
    <input type="button" class="btn btn-primary" onclick="printDiv('print-table')" value="Print Document" />
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#caradownload">
            Cara Download PDF
        </button>
        <?php endif; ?>

    
    <div class="collapse" id="des5">
        <div class="card card-body">
            <p>
                Tuliskan judul artikel karya ilmiah DTPS yang disitasi dalam <b> 3 tahun terakhir  </b> dengan
                mengikuti format Tabel berikut ini. Judul artikel yang disitasi harus relevan dengan
                bidang program studi. <br> <br>
            </p>
        </div> 
    </div>
    
    <!-- Modal Tambah Data Karya Ilmiah DTPS -->
    <div class="modal fade" id="modalkaryailmiah" tabindex="-1" aria-labelledby="modalkaryailmiah" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modalkaryailmiah">Tambah Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.kinerjadosenmodal.karilm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
    </div>

    
    <?php echo $__env->make('tab.kinerjadosentab.karyailmiahdtpstable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


     <?php $__currentLoopData = $karyailmiah['karyailmiah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <!-- Modal Edit Data K.Ilm DTPS -->
    <div class="modal fade" id="modalkaryailmiahedit-<?php echo e($karil->id); ?>" tabindex="-1" aria-labelledby="modalkaryailmiahedit" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modalkaryailmiahedit">Edit Data <?php echo e($karil->nama_dosen); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.kinerjadosenmodal.karilmedit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        </div>
    
        <!-- Modal Delete Data K.Ilm DTPS -->
        <div class="modal fade" id="modalkaryailmiahdelete-<?php echo e($karil->id); ?>" tabindex="-1" aria-labelledby="modalkaryailmiahdelete" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="modalkaryailmiahdelete">Hapus Data <?php echo e($karil->nama_dosen); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <?php echo $__env->make('partials.kinerjadosenmodal.karilmdelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/tab/kinerjadosentab/karyailmiahdtps.blade.php ENDPATH**/ ?>