<?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(url('/tata-pamong-tata-kelola-kerjasama')); ?>" method="GET">
    <div id="print-table" class="container-fluid">
        <table width="90%" id='form-print' class="table text-center table-bordered ">
            <thead>
                <tr>
                    <th class="align-middle" scope="col" rowspan="2">NO</th>
                    <th class="align-middle" scope="col" rowspan="2">Jenis Penggunaan</th>
                    <th scope="col" colspan="4">Unit Pengelola Program Studi (Rp.)</th>
                    <th scope="col" colspan="4">Program Studi (Rp.)</th>
                    <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                    <th class="align-middle" scope="col" rowspan="2">Opsi</th>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th scope="col">TS-2</th>
                    <th scope="col">TS-1</th>
                    <th scope="col">TS</th>
                    <th scope="col">Rata-rata</th>
                    <th scope="col">TS-2</th>
                    <th scope="col">TS-1</th>
                    <th scope="col">TS</th>
                    <th scope="col">Rata-rata</th>
                </tr>
                
        
            </thead>

            <tbody class="text-dark">
                <tr>
                    <td class="text-center putih"> 1 </td>
                    <td class="text-left putih" colspan="5"> <b>Biaya Operasional Pendidikan</b>  </td>
                    <td colspan="5" style="background-color: #e7e7e7"> </td>
                </tr>
                <?php $__currentLoopData = $ts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->biaya->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $ts_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->biaya->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $ts_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->biaya->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $ts_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->biaya->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $ts_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->sarana->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td colspan="2" class="text-left"><b>Jumlah :</b> </td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($jumlah1['ts']); ?></td>
                    <td>Rp. <?php echo e($jumlah1['average']); ?></td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($jumlah1['ps_ts']); ?></td>
                    <td>Rp. <?php echo e($jumlah1['ps_average']); ?></td>
                    <td></td>
                </tr>

                <?php $__currentLoopData = $ts_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->sarana->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php $__currentLoopData = $ts_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->sarana->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td colspan="2" class="text-left"><b>Jumlah :</b> </td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($jumlah2['ts']); ?></td>
                    <td>Rp. <?php echo e($jumlah2['average']); ?></td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($jumlah2['ps_ts']); ?></td>
                    <td>Rp. <?php echo e($jumlah2['ps_average']); ?></td>
                    <td></td>
                </tr>

                <?php $__currentLoopData = $ts_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->sarana->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $ts_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->sarana->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $ts_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td style="text-align: left"><?php echo e($data->sarana->text); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->unit_pengelola_ts); ?></td>
                        <td>Rp.<?php echo e($data->unit_pengelola_average); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts2_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts1_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ts_sarana7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>Rp.<?php echo e($data->ps_ts); ?></td>
                        <td>Rp.<?php echo e($data->ps_average); ?></td>
                    
                        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
                        <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                            <li><a type="button" href="" class="btn btn-primary" data-toggle="modal" data-target="#modalsaranaedit-<?php echo e($data->id); ?>"><i class="fas fa-edit"></i></a></li>
                            <li>
                                <a type="button" class="btn btn-danger" href="/keuangan-sarana-prasarana/<?php echo e($data->id); ?>" data-toggle="modal" data-target="#modalsaranadelete-<?php echo e($data->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
                        </ul></td>
                        <?php endif; ?>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                <tr>
                    <td colspan="2" class="text-left"><b>Jumlah :</b> </td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($jumlah3['ts']); ?></td>
                    <td>Rp. <?php echo e($jumlah3['average']); ?></td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($jumlah3['ps_ts']); ?></td>
                    <td>Rp. <?php echo e($jumlah3['ps_average']); ?></td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="2" class="text-left"><b>Total :</b> </td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($total['ts']); ?></td>
                    <td>Rp. <?php echo e($total['average']); ?></td>
                    <td>Rp. </td>
                    <td>Rp. </td>
                    <td>Rp. <?php echo e($total['ps_ts']); ?></td>
                    <td>Rp. <?php echo e($total['ps_average']); ?></td>
                    <td></td>
                </tr>

            </tbody>
        </table> 
    
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/tab/kesaprastab/kesaprastable.blade.php ENDPATH**/ ?>