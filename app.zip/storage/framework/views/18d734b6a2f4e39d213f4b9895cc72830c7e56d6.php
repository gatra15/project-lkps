


<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
            <h1>TAB KEUANGAN, SARANA, DAN PRASARANA</h1>
    </div>
</div>

<!-- HEAD CARD -->
<div class="content">
    <div class="container-fluid">
            <div class="card">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>

                <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>


    <div class="card-header">
        <ul class="nav nav-tabs card-header-tabs" id="bologna-list" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" href="#" role="tab" aria-controls="kualitas" aria-selected="true">Keuangan, Sarana, dan Prasarana</a>
            </li>
        </ul>
    </div>

    <!-- CARD BODY  -->
    <div class="card-body">
        <div class="tab-content mt-3">
            <div class="tab-content" id="myTabContent">

            
            <div class="tab-pane active" id="kerjasama" role="tabpanel">
                <p class="d-flex justify-content-between">
                    <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                        Deskripsi
                    </a>
                </p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('download file')): ?>
                <a href="/keuangan-sarana-prasarana/download/excel" class="btn btn-success">Excel</a>
                <a href="/keuangan-sarana-prasarana/download/csv" class="btn btn-success">CSV</a>
                <input type="button" class="btn btn-primary" onclick="printDiv('print-table')" value="Print Document" />
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#caradownload">
                    Cara Download PDF
                </button>
                <?php endif; ?>
            
                <div class="collapse" id="collapseExample">
                <div class="card card-body">
                    <p>
                    Tuliskan data penggunaan dana  yang dikelola oleh UPPS dan data penggunaan dana yang dialokasikan ke program studi yang diakreditasi dalam <b>3 tahun terakhir</b> dengan mengikuti format berikut ini.
                    </p>
                </div>
                </div>



<?php echo $__env->make('tab.kesaprastab.kesaprastable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__currentLoopData = $ts_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
        <!-- Modal Edit -->
        <div class="modal fade" id="modalsaranaedit-<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="modalsaranaedit" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalsaranaedit">Edit Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <?php echo $__env->make('partials.keuangansaprasmodal.kesaprasedit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
        </div>
        <!-- Modal De;ete -->
        <div class="modal fade" id="modalsaranadelete-<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="modalmahasiswadelete" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalmahasiswadelete">Hapus Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <?php echo $__env->make('partials.keuangansaprasmodal.kesaprasdelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
        </div>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/tab/keuanganSarpras.blade.php ENDPATH**/ ?>