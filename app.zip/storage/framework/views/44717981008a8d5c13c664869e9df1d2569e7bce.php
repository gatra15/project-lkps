
<style>
    
th {
    position: relative;
    padding: 10px;
}

th span {
  display:inline-table;
  writing-mode: tb-rl;
  white-space:pre;
}


</style>
<div id="print-table3">
    <table class="table table-bordered table-condensed">
    <thead>
    
    <tr>
    <th scope="col" class="align-middle text-center" rowspan="2">No</th>
    <th scope="col" class="align-middle text-center" rowspan="2"> <span> Semester</span></th>
    <th scope="col" class="align-middle text-center" rowspan="2">Kode <br> Mata <br> Kuliah</th>
    <th scope="col" class="align-middle text-center" rowspan="2">Nama <br> Mata <br> Kuliah</th>
    <th scope="col" class="align-middle text-center" rowspan="2">Mata Kuliah <br> Kompetensi <sup>1)</sup></th>
    <th scope="col" class="align-middle text-center" colspan="3">Bukti Kredit <br> (sks)</th>
    <th scope="col" rowspan="2"><span>Konversi Kredit ke Jam <sup>2)</sup></span></th>
    <th scope="col" class="align-middle text-center" colspan="4">Bukti Kredit <br> (sks)</th>
    <th scope="col" class="align-middle text-center" rowspan="2">Dokumen <br> Rencana <br> Pembela- <br> jaran <sup>3)</sup></th>
    <th scope="col" class="align-middle text-center" rowspan="2">Unit <br> Penye- <br> lenggara</th>
    <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
    <th scope="col" class="align-middle text-center" rowspan="2">Opsi</th>
    <?php endif; ?>
    </tr>
    <tr>
        <th> <span class="text-center">Kuliah/ Responsi/ <br> Tutorial</span>  </th>
        <th> <span class="text-center">Seminar</span> </th>
        <th> <span class="text-center">Praktikum/ Praktik/ <br> Praktik Lapangan</span> </th>
        <th> <span class="text-center">Sikap</span>  </th>
        <th> <span class="text-center">Pengetahuan</span> </th>
        <th> <span class="text-center">Keterampilan <br> Umum</span> </th>
        <th> <span class="text-center">Keterampilan <br> Khusus</span> </th>
    </tr>
    
    </thead>
    
    <tbody>
        <?php $__currentLoopData = $kurikulum['kurikulum']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($kur->semester); ?></td>
            <td><?php echo e($kur->kode_mata_kuliah); ?></td>
            <td><?php echo e($kur->nama_mata_kuliah); ?></td>
            <td><?php echo e($kur->mata_kuliah_kompetensial == '1' ? 'V' : ''); ?></td>
            <td><?php echo e($kur->bobot_kuliah); ?></td>
            <td><?php echo e($kur->bobot_seminar); ?></td>
            <td><?php echo e($kur->bobot_praktikum); ?></td>
            <td><?php echo e($kur->konversi_kredit_jam); ?> Jam</td>
            <td><?php echo e($kur->capaian_sikap == '1' ? 'V' : ''); ?></td>
            <td><?php echo e($kur->capaian_pengetahuan == '1' ? 'V' : ''); ?></td>
            <td><?php echo e($kur->capaian_ketrampilan_umum == '1' ? 'V' : ''); ?></td>
            <td><?php echo e($kur->capaian_ketrampilan_khusus == '1' ? 'V' : ''); ?></td>
            <td><?php echo e($kur->document_rencana_pembelajaran == '1' ? 'V' : ''); ?></td>
            <td><?php echo e($kur->unit_penyelenggara); ?></td>
            <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
            <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                <li><a type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalkurikulumedit-<?php echo e($kur->id); ?>"><i class="fas fa-edit"></i></a></li>
                <li>
                    <a type="button" class="btn btn-danger" href="/pendidikan/<?php echo e($kur->id); ?>" data-toggle="modal" data-target="#modalkurikulumdelete-<?php echo e($kur->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
            </ul></td>
            <?php endif; ?>
        </tr>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        <tr>
        <td class="putih align-middle text-center" colspan="4"><b>Jumlah </b></td>
        <td class="putih align-middle text-center"><?php echo e($kurikulum['makul']); ?></td>
        <td class="putih align-middle text-center"><?php echo e($kurikulum['bobot_kuliah']); ?></td>
        <td class="putih align-middle text-center"><?php echo e($kurikulum['bobot_seminar']); ?></td>
        <td class="putih align-middle text-center"><?php echo e($kurikulum['bobot_praktikum']); ?></td>
        <td class="putih align-middle text-center"><?php echo e($kurikulum['konversi_kredit_jam']); ?> <b>Jam</b> </td>
        <td colspan="7"></td>
        </tr>
       
    </tbody>
    </table> 
</div>


<?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/tab/pendidikantab/kurikulumtable.blade.php ENDPATH**/ ?>