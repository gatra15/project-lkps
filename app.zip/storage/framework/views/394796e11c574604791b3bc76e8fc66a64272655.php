
<div id="print-table2">
    <table id='form-print' class="table text-center table-bordered table-condensed">
    <thead>
    <tr>
        <th class="align-middle" scope="col" rowspan="2">Tahun Lulus</th>
        <th class="align-middle" scope="col" rowspan="2">Jumlah Lulusan</th>
        <th scope="col" colspan="3">Indeks Prestasi Kumulatif (IPK)</th>
        <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
        <th class="align-middle" scope="col" rowspan="2">Opsi</th>
        <?php endif; ?>
    </tr>
    <tr>
    <th scope="col">Min.</th>
    <th scope="col">Rata-rata</th>
    <th scope="col">Maks.</th>
    </tr>
    
    </thead>
    
    <tbody class="text-dark">
    <?php $__currentLoopData = $capaianPembelajaran['capaian']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $capaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php echo e($capaian->jumlah_lulusan); ?>

            <td><?php echo e($key == sizeof($capaianPembelajaran['capaian'])-1 ? 'TS' : 'TS-'.(sizeof($capaianPembelajaran['capaian'])-1-$key)); ?></td>
            <td><?php echo e($capaian->jumlah_lulusan); ?></td>
            <td><?php echo e($capaian->ipk_min); ?></td>
            <td><?php echo e($capaian->ipk_avg); ?></td>
            <td><?php echo e($capaian->ipk_max); ?></td>
            <?php if(auth()->check() && auth()->user()->hasRole('perwakilan')): ?>
            <td><ul class="action-list d-flex justify-content-center mr-1" id="action">
                <li><a type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalcapaianedit-<?php echo e($capaian->id); ?>"><i class="fas fa-edit"></i></a></li>
                <li>
                    <a type="button" class="btn btn-danger" href="/luaran-capaian-tridharma/<?php echo e($capaian->id); ?>" data-toggle="modal" data-target="#modalcapaiandelete-<?php echo e($capaian->id); ?>"><i class="fas fa-trash btn-del"></i></a></li>
            </ul></td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table> 
    </div>
<?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lkps\resources\views/tab/luarantab/capaiantable.blade.php ENDPATH**/ ?>