<form action="/kinerja-dosen/penelitian-dtps/<?php echo e($ts->tahun_laporan); ?>/<?php echo e($ts->sumber_id); ?>" method="post">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <h5 class="text-center">Yakin Ingin Menghapus ? </h5>
        <input type="hidden" name="sumber_id" value="<?php echo e($ts->sumber_id); ?>">
        <?php $__currentLoopData = $penelitians['ts2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="jumlah_ts2" value="">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $penelitians['ts1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="jumlah_ts1" value="">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="jumlah_ts" value="">
        <input type="hidden" name="jumlah" value="">
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-danger">Yakin</button>
    </div>
</form><?php /**PATH C:\laragon\www\lkps\resources\views/partials/kinerjadosenmodal/penelitiandelete.blade.php ENDPATH**/ ?>